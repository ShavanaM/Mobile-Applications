package com.example.dutclinicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeScreen2Activity extends AppCompatActivity {

    FirebaseAuth auth;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen2);
        Button button = findViewById(R.id.btnCancelAppt);
        Button button1 = findViewById(R.id.btnMakeAppt);
        Button button2 = findViewById(R.id.btnViewAppt);
        Button button3 = findViewById(R.id.btnLogout);
        TextView textView = findViewById(R.id.txtvStaffStudNo);
        auth =FirebaseAuth.getInstance();
        user =auth.getCurrentUser();

        if (user == null){

            Intent intent = new Intent(getApplicationContext(),StaffStudLoginActivity.class);
            startActivity(intent);
            finish();
        }
        else {
            textView.setText(user.getEmail());
        }

        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen2Activity.this, CancelApptActivity.class);
                startActivity(intent);
                finish();
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen2Activity.this, MakeApptActivity.class);
                startActivity(intent);
                finish();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen2Activity.this, ViewApptActivity.class);
                startActivity(intent);
                finish();
            }
        });

       button3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               FirebaseAuth.getInstance().signOut();
               Intent intent = new Intent(HomeScreen2Activity.this,StaffStudLoginActivity.class);
               startActivity(intent);
               finish();





           }
       });


    }
}