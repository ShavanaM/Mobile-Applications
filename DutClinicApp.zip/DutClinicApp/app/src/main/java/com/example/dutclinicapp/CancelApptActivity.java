package com.example.dutclinicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CancelApptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_appt);
    }
}