package com.example.dutclinicapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class StaffStudSignUp2Activity extends AppCompatActivity {

    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_stud_sign_up2);
        mAuth = FirebaseAuth.getInstance();
        Button button = findViewById(R.id.btnback3);
        EditText email = findViewById(R.id.edtemailsss);
        EditText pwd = findViewById(R.id.edtpwdsss1);
        Button button1 = findViewById(R.id.btnsss1);
        ProgressBar progressBar = findViewById(R.id.progressbar);
        TextView textView = findViewById(R.id.login);


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),StaffStudLoginActivity.class);
                startActivity(intent);
                finish();

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();

            }
        });


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emailaddress, password;
                emailaddress = email.getText().toString();
                password = pwd.getText().toString();

                if (TextUtils.isEmpty(emailaddress)) {
                    Toast.makeText(StaffStudSignUp2Activity.this, "Please Enter an Dut Email", Toast.LENGTH_SHORT).show();

                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(StaffStudSignUp2Activity.this, "Please Enter a Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.createUserWithEmailAndPassword(emailaddress, password)
                        .addOnCompleteListener(task -> {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful()) {
                                Toast.makeText(StaffStudSignUp2Activity.this, "Account Created.",
                                        Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),HomeScreen2Activity.class);
                                startActivity(intent);
                                finish();

                            } else {
                                // If sign in fails, display a message to the user.

                                Toast.makeText(StaffStudSignUp2Activity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();


                            }
                        });


            }
            });

        }

    }
