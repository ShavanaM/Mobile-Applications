package com.example.dutclinicapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class StaffStudLoginActivity extends AppCompatActivity {

    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_stud_login);
        Button button = findViewById(R.id.btnback2);
        TextView textView = findViewById(R.id.txtvssl4);
        Button button1 = findViewById(R.id.btnssl);
        EditText editText = findViewById(R.id.edtEmailssl);
        EditText editText1 = findViewById(R.id.edtpwdssl);
        ProgressBar progressBar = findViewById(R.id.progressbar);


     button.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent = new Intent(StaffStudLoginActivity.this,MainActivity.class);
             startActivity(intent);


         }
     });

     textView.setOnClickListener((new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent = new Intent(StaffStudLoginActivity.this,StaffStudSignUp2Activity.class);
             startActivity(intent);

         }
     }));

  button1.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {

            String emailaddress, password;
            emailaddress = editText.getText().toString();
            password = editText1.getText().toString();

            if (TextUtils.isEmpty(emailaddress)) {
                Toast.makeText(StaffStudLoginActivity.this, "Please Enter an Dut Email", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(password)) {
                Toast.makeText(StaffStudLoginActivity.this, "Please Enter a Password", Toast.LENGTH_SHORT).show();
                return;
            }


          mAuth.signInWithEmailAndPassword(emailaddress, password)
                  .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                      @Override
                      public void onComplete(@NonNull Task<AuthResult> task) {
                          if (task.isSuccessful()) {
                              progressBar.setVisibility(View.GONE);
                              // Sign in success, update UI with the signed-in user's information


                              Toast.makeText(StaffStudLoginActivity.this, "Authentication Successful.",Toast.LENGTH_SHORT).show();
                              Intent intent = new Intent(StaffStudLoginActivity.this,HomeScreen2Activity.class);
                              startActivity(intent);


                          } else {
                              // If sign in fails, display a message to the user.

                              Toast.makeText(StaffStudLoginActivity.this, "Authentication failed.",Toast.LENGTH_SHORT).show();

                          }
                      }
                  });

      }
  });

    }

}
